﻿using System;

namespace $safeprojectname$
{
    public class User
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}
